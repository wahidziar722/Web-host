from flask import Flask
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "CHANGE_THIS_SECRET_KEY"
    app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024
    app.config["PROJECTS_DIR"] = BASE_DIR / "data" / "projects"
    app.config["LOGS_DIR"] = BASE_DIR / "data" / "logs"

    app.config["PROJECTS_DIR"].mkdir(parents=True, exist_ok=True)
    app.config["LOGS_DIR"].mkdir(parents=True, exist_ok=True)

    from .routes import bp
    app.register_blueprint(bp)
    return app
