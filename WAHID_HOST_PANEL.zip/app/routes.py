from flask import Blueprint, current_app, render_template, request, redirect, url_for, flash, jsonify
from pathlib import Path
from werkzeug.utils import secure_filename
import shutil
import zipfile
import re

from .runner import start_project, stop_project, restart_project, status, stop_all

bp = Blueprint("main", __name__)

NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")

def projects_dir():
    return Path(current_app.config["PROJECTS_DIR"])

def safe_name(value):
    value = secure_filename(value or "")
    if not NAME_RE.fullmatch(value):
        return None
    return value

def list_projects():
    out = []
    for p in sorted(projects_dir().iterdir()) if projects_dir().exists() else []:
        if p.is_dir():
            st, pid = status(p.name)
            out.append({"name": p.name, "status": st, "pid": pid})
    return out

@bp.get("/")
def index():
    projects = list_projects()
    running = sum(x["status"] == "running" for x in projects)
    return render_template("index.html", projects=projects, running=running)

@bp.post("/create")
def create():
    name = safe_name(request.form.get("name"))
    if not name:
        flash("Invalid project name.")
        return redirect(url_for("main.index"))
    p = projects_dir() / name
    p.mkdir(parents=True, exist_ok=True)
    main = p / "main.py"
    if not main.exists():
        main.write_text("print('WAHID HOST PANEL project started')\\n", encoding="utf-8")
    flash(f"Project {name} created.")
    return redirect(url_for("main.index"))

@bp.post("/upload")
def upload():
    name = safe_name(request.form.get("name"))
    f = request.files.get("file")
    if not name or not f or not f.filename:
        flash("Project name and file are required.")
        return redirect(url_for("main.index"))

    p = projects_dir() / name
    p.mkdir(parents=True, exist_ok=True)
    filename = secure_filename(f.filename)

    if filename.lower().endswith(".zip"):
        tmp = p / "__upload.zip"
        f.save(tmp)
        try:
            with zipfile.ZipFile(tmp) as z:
                for member in z.infolist():
                    target = (p / member.filename).resolve()
                    if not str(target).startswith(str(p.resolve()) + str(Path.sep)):
                        raise ValueError("Unsafe ZIP path.")
                z.extractall(p)
        except Exception as e:
            shutil.rmtree(p, ignore_errors=True)
            p.mkdir(parents=True, exist_ok=True)
            flash(f"ZIP rejected: {e}")
        finally:
            tmp.unlink(missing_ok=True)
    else:
        f.save(p / filename)

    flash(f"Uploaded to {name}.")
    return redirect(url_for("main.index"))

@bp.post("/project/<name>/start")
def start(name):
    if not safe_name(name):
        return "Bad project name", 400
    ok, msg = start_project(name, projects_dir(), current_app.config["LOGS_DIR"])
    flash(msg)
    return redirect(url_for("main.index"))

@bp.post("/project/<name>/stop")
def stop(name):
    if not safe_name(name):
        return "Bad project name", 400
    ok, msg = stop_project(name)
    flash(msg)
    return redirect(url_for("main.index"))

@bp.post("/project/<name>/restart")
def restart(name):
    if not safe_name(name):
        return "Bad project name", 400
    ok, msg = restart_project(name, projects_dir(), current_app.config["LOGS_DIR"])
    flash(msg)
    return redirect(url_for("main.index"))

@bp.post("/project/<name>/delete")
def delete(name):
    if not safe_name(name):
        return "Bad project name", 400
    stop_project(name)
    shutil.rmtree(projects_dir() / name, ignore_errors=True)
    flash(f"Deleted {name}.")
    return redirect(url_for("main.index"))

@bp.get("/api/status")
def api_status():
    return jsonify(list_projects())

@bp.get("/logs/<name>")
def logs(name):
    if not safe_name(name):
        return "Bad project name", 400
    p = Path(current_app.config["LOGS_DIR"]) / f"{name}.log"
    if not p.exists():
        return "No logs yet."
    text = p.read_text(encoding="utf-8", errors="replace")
    return text[-30000:]

@bp.post("/stop-all")
def stop_all_route():
    stop_all()
    flash("Stop signal sent to all running projects.")
    return redirect(url_for("main.index"))
