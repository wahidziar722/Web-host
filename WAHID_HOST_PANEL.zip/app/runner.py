import os
import sys
import signal
import subprocess
import threading
from pathlib import Path

PROCESSES = {}
LOCK = threading.Lock()

def _log_path(logs_dir, name):
    return Path(logs_dir) / f"{name}.log"

def _append(logfile, text):
    logfile.parent.mkdir(parents=True, exist_ok=True)
    with logfile.open("a", encoding="utf-8", errors="replace") as f:
        f.write(text)
        f.flush()

def _install_requirements(project_dir, logfile):
    req = project_dir / "requirements.txt"
    if not req.exists():
        return True
    cmd = [sys.executable, "-m", "pip", "install", "-r", str(req)]
    p = subprocess.run(
        cmd, cwd=project_dir, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True
    )
    _append(logfile, "\\n$ " + " ".join(cmd) + "\\n" + p.stdout + "\\n")
    return p.returncode == 0

def _reader(name, pipe, logfile):
    try:
        for line in iter(pipe.readline, ""):
            if line:
                _append(logfile, line)
    finally:
        pipe.close()

def start_project(name, projects_dir, logs_dir):
    project_dir = Path(projects_dir) / name
    logfile = _log_path(logs_dir, name)

    with LOCK:
        p = PROCESSES.get(name)
        if p and p.poll() is None:
            return False, "Already running."

        entry = project_dir / "main.py"
        if not entry.exists():
            candidates = sorted(project_dir.glob("*.py"))
            if not candidates:
                return False, "No Python entry file found."
            entry = candidates[0]

        _append(logfile, f"\\n=== START {name} ===\\n")
        if not _install_requirements(project_dir, logfile):
            return False, "requirements.txt installation failed. Check logs."

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        env["PYTHONPATH"] = str(project_dir)

        p = subprocess.Popen(
            [sys.executable, "-u", str(entry)],
            cwd=project_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=env,
            start_new_session=True,
        )
        PROCESSES[name] = p

        t = threading.Thread(target=_reader, args=(name, p.stdout, logfile), daemon=True)
        t.start()

        return True, f"Started PID {p.pid}."

def stop_project(name):
    with LOCK:
        p = PROCESSES.get(name)
        if not p or p.poll() is not None:
            return False, "Project is not running."
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        except Exception:
            p.terminate()
        return True, "Stop signal sent."

def restart_project(name, projects_dir, logs_dir):
    stop_project(name)
    import time
    time.sleep(0.4)
    return start_project(name, projects_dir, logs_dir)

def status(name):
    p = PROCESSES.get(name)
    if p and p.poll() is None:
        return "running", p.pid
    return "stopped", None

def stop_all():
    names = list(PROCESSES.keys())
    results = []
    for name in names:
        results.append((name, stop_project(name)))
    return results
