# WAHID HOST PANEL

A private Python hosting/control panel.

Features:
- Dashboard
- Create/upload Python projects
- Start / stop / restart projects
- Live-ish log viewer
- Project status
- Delete projects
- Per-project working directory
- Optional requirements.txt installation

## Important
This is intended for a trusted/private server. Running arbitrary Python code is dangerous.
For public/untrusted uploads, run projects inside Docker/VM sandboxes with CPU, RAM,
network, filesystem and process limits. The starter version here runs projects as a
separate OS process and should NOT be exposed publicly without authentication and
additional isolation.

## Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

Open:
http://127.0.0.1:8080

For production:
```bash
gunicorn -w 2 -b 0.0.0.0:8080 "app:create_app()"
```
